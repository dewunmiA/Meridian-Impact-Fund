
import React from 'react';

// Curated Unsplash images for "Impact in Action"
const EVENT_IMAGES = [
    "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&q=80&w=400", // Group Hug/Team
    "https://images.unsplash.com/photo-1531545514256-b1400bc00f31?auto=format&fit=crop&q=80&w=400", // Meeting
    "https://images.unsplash.com/photo-1576267423445-b2e0074d68a4?auto=format&fit=crop&q=80&w=400", // Event/Audience
    "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=400", // Collaboration
    "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&q=80&w=400", // People/Connection
    "https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?auto=format&fit=crop&q=80&w=400", // Summit/Panel
];

const ContactSection: React.FC = () => {
    // Duplicate array for seamless scrolling
    const scrollingImages = [...EVENT_IMAGES, ...EVENT_IMAGES, ...EVENT_IMAGES];

  return (
    <section id="contact" className="py-24 px-6 relative overflow-hidden scroll-mt-20">
      <div className="container mx-auto">
        <div className="bg-[#1A1A1A] rounded-[3rem] p-12 md:p-24 text-center relative overflow-hidden mb-16">
             
            {/* Decorative background circles */}
            <div className="absolute top-0 left-0 w-64 h-64 bg-[#FF5E3A] rounded-full mix-blend-overlay filter blur-3xl opacity-20 -translate-x-1/2 -translate-y-1/2"></div>
            <div className="absolute bottom-0 right-0 w-64 h-64 bg-blue-500 rounded-full mix-blend-overlay filter blur-3xl opacity-20 translate-x-1/2 translate-y-1/2"></div>

            <div className="relative z-10 max-w-3xl mx-auto">
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Let's Drive Change Together</h2>
                <p className="text-gray-300 text-xl leading-relaxed mb-10">
                Whether you are a local implementor seeking resources, a social impact firm looking to scale, or a partner ready to collaborate—we want to hear from you.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <a 
                    href="mailto:contact@meridianimpact.org" 
                    className="bg-white text-black font-bold py-4 px-12 rounded-full hover:bg-gray-100 transition-all duration-300 text-lg shadow-lg hover:shadow-xl hover:-translate-y-1"
                    >
                    Get in Touch
                    </a>
                    <a 
                    href="#projects"
                    className="bg-transparent border border-gray-600 text-white font-bold py-4 px-12 rounded-full hover:border-white transition-all duration-300 text-lg"
                    >
                    View Our Work
                    </a>
                </div>
            </div>
        </div>

        {/* Meridian In Action Carousel */}
        <div className="relative">
            <h3 className="text-center text-sm font-bold text-[#1A1A1A] uppercase tracking-widest mb-8">
                Meridian Impact in Action
            </h3>
            <div className="relative w-full overflow-hidden">
                <div className="absolute top-0 left-0 h-full w-20 bg-gradient-to-r from-[#F8F7F4] to-transparent z-10 pointer-events-none"></div>
                <div className="absolute top-0 right-0 h-full w-20 bg-gradient-to-l from-[#F8F7F4] to-transparent z-10 pointer-events-none"></div>
                
                <div className="flex animate-marquee-images hover:pause">
                    {scrollingImages.map((src, index) => (
                        <div key={index} className="flex-shrink-0 mx-4">
                            <div className="w-[300px] h-[200px] rounded-2xl overflow-hidden shadow-md transform transition-transform hover:scale-105">
                                <img src={src} alt="Meridian Impact Event" className="w-full h-full object-cover" />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>

      </div>
      <style>{`
        .animate-marquee-images {
          animation: marquee-images 50s linear infinite;
        }
        .hover\\:pause:hover {
          animation-play-state: paused;
        }
        @keyframes marquee-images {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </section>
  );
};

export default ContactSection;
