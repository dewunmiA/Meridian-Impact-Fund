
import React, { useEffect } from 'react';

const CloseIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

interface AnchorModalProps {
    isOpen: boolean;
    onClose: () => void;
    onContact: () => void;
}

const AnchorModal: React.FC<AnchorModalProps> = ({ isOpen, onClose, onContact }) => {
    useEffect(() => {
        const handleEsc = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        if (isOpen) {
            window.addEventListener('keydown', handleEsc);
            document.body.style.overflow = 'hidden';
        }
        return () => {
            window.removeEventListener('keydown', handleEsc);
            document.body.style.overflow = 'unset';
        };
    }, [isOpen, onClose]);

    const handleContactClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        onContact();
    };

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[60] p-4 transition-opacity duration-300"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
        >
            <div 
                className="bg-white rounded-2xl shadow-xl w-full max-w-4xl overflow-hidden transform transition-all duration-300 animate-fade-in-scale flex flex-col max-h-[90vh]"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="bg-[#1A1A1A] p-6 text-white flex justify-between items-center flex-shrink-0">
                    <h2 className="text-2xl font-bold tracking-wide">The ANCHOR Framework</h2>
                    <button onClick={onClose} className="text-white hover:text-[#FF5E3A] transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                
                <div className="overflow-y-auto custom-scrollbar">
                    <div className="p-8">
                        <p className="text-gray-600 mb-8 text-lg leading-relaxed">
                            Our proprietary methodology for driving systemic change. The ANCHOR Framework ensures that every partnership and project is built on a foundation of sustainable, locally-led development.
                        </p>
                        
                        <div className="grid gap-4 mb-12">
                            {[
                                { letter: 'A', word: 'Assess', desc: 'Conduct landscape scans, stakeholder and power mapping, and funding and narrative diagnostics to understand the current system.' },
                                { letter: 'N', word: 'Navigate', desc: 'Co-create impact blueprints, frameworks, and partnership structures that chart clear pathways from intention to implementation.' },
                                { letter: 'C', word: 'Connect', desc: 'Build and formalise relationships across corporates, governments, funders, and creatives to align incentives and resources.' },
                                { letter: 'H', word: 'Harmonise', desc: 'Align goals, roles, timelines, and communication so partners move in sync rather than in silos.' },
                                { letter: 'O', word: 'Organise', desc: 'Provide implementation support, coordination, reporting, and learning loops that keep programmes on track and adaptive.' },
                                { letter: 'R', word: 'Reinforce', desc: 'Amplify impact through storytelling, advocacy, and scale pathways via ecosystems like C4D, TGM, and other strategic partners.' },
                            ].map((item, index) => (
                                <div key={index} className="flex items-start p-3 hover:bg-gray-50 rounded-lg transition-colors border border-transparent hover:border-gray-100">
                                    <span className="text-3xl font-bold text-[#FF5E3A] w-14 flex-shrink-0">{item.letter}</span>
                                    <div>
                                        <h3 className="text-lg font-bold text-[#1A1A1A]">{item.word}</h3>
                                        <p className="text-gray-600 text-sm mt-1 leading-relaxed">{item.desc}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Integrated Training Section */}
                    <div className="bg-[#1A1A1A] text-white p-8 md:p-12 relative overflow-hidden">
                        {/* Background Elements */}
                        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF5E3A] rounded-full filter blur-[100px] opacity-10 translate-x-1/3 -translate-y-1/3 pointer-events-none"></div>

                        <div className="relative z-10">
                            <div className="inline-block bg-[#FF5E3A]/20 border border-[#FF5E3A] text-[#FF5E3A] text-xs font-bold px-4 py-1.5 rounded-full tracking-wider mb-6">
                                TRAINING & DEVELOPMENT
                            </div>
                            
                            <div className="grid md:grid-cols-2 gap-10">
                                <div>
                                    <h2 className="text-2xl md:text-3xl font-bold mb-4 leading-tight">
                                        Master the <span className="text-[#FF5E3A]">ANCHOR Framework</span>
                                    </h2>
                                    <p className="text-gray-300 mb-6 leading-relaxed text-sm md:text-base">
                                        Collaboration isn't accidental; it's engineered. Dewunmi developed this framework to help teams design, manage, and sustain high-impact partnerships.
                                    </p>
                                    <p className="text-gray-300 mb-8 leading-relaxed text-sm md:text-base">
                                        Organizations can now engage Dewunmi to facilitate workshops and training sessions, equipping their leadership and staff with the skills to turn transactional connections into transformational systems of change.
                                    </p>
                                    <a 
                                        href="#contact" 
                                        onClick={handleContactClick}
                                        className="inline-block bg-white text-[#1A1A1A] font-bold py-3 px-8 rounded-full hover:bg-gray-200 transition-colors duration-300 text-sm"
                                    >
                                        Inquire About Training
                                    </a>
                                </div>

                                <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl">
                                    <h3 className="text-lg font-bold mb-4">What Your Team Will Learn</h3>
                                    <ul className="space-y-3">
                                        {[
                                            "Alignment: Setting shared goals that stick.",
                                            "Network: Leveraging ecosystems effectively.",
                                            "Collaboration: Moving beyond 'meetings'.",
                                            "Holistic Design: Systems thinking.",
                                            "Ownership: Building local capacity.",
                                            "Resilience: Future-proofing partnerships."
                                        ].map((item, i) => (
                                            <li key={i} className="flex items-start text-sm">
                                                <div className="mt-1 w-4 h-4 rounded-full bg-[#FF5E3A] flex items-center justify-center flex-shrink-0 text-white text-[10px] mr-3">
                                                    ✓
                                                </div>
                                                <span className="text-gray-300">{item}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>{`
                @keyframes fadeInScale {
                    from { opacity: 0; transform: scale(0.95); }
                    to { opacity: 1; transform: scale(1); }
                }
                .animate-fade-in-scale {
                    animation: fadeInScale 0.3s ease-out forwards;
                }
                .custom-scrollbar::-webkit-scrollbar {
                    width: 8px;
                }
                .custom-scrollbar::-webkit-scrollbar-track {
                    background: transparent;
                }
                .custom-scrollbar::-webkit-scrollbar-thumb {
                    background-color: rgba(0,0,0,0.1);
                    border-radius: 20px;
                }
            `}</style>
        </div>
    );
};

export default AnchorModal;
