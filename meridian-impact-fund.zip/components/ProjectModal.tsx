
import React, { useEffect } from 'react';
import { Project } from '../types';
import AnchorText from './AnchorText';

const LinkIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244" />
    </svg>
);

const CloseIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);


interface ProjectModalProps {
    project: Project | null;
    onClose: () => void;
    onOpenAnchor: () => void;
}

const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose, onOpenAnchor }) => {
    useEffect(() => {
        const handleEsc = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        window.addEventListener('keydown', handleEsc);

        if (project) {
            document.body.style.overflow = 'hidden';
        }

        return () => {
            window.removeEventListener('keydown', handleEsc);
            document.body.style.overflow = 'unset';
        };
    }, [project, onClose]);
    
    if (!project) return null;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 transition-opacity duration-300"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
            aria-labelledby="project-modal-title"
        >
            <div 
                className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto transform transition-all duration-300 scale-95 opacity-0 animate-fade-in-scale"
                onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside modal
            >
                <div className="p-6 md:p-8 sticky top-0 bg-white border-b z-10 flex justify-between items-start">
                    <div>
                        <h2 id="project-modal-title" className="text-2xl font-bold text-[#1A1A1A]">{project.title}</h2>
                        <p className="text-sm text-gray-500 font-semibold mt-1">{project.association}</p>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-700 p-1 -mt-1 -mr-1" aria-label="Close modal">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>

                <div className="p-6 md:p-8">
                    <div className="text-gray-600 mb-6 leading-relaxed">
                        <AnchorText text={project.description} onOpen={onOpenAnchor} />
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-8">
                        <div>
                            <h4 className="text-lg font-semibold text-gray-800 mb-3 border-b pb-2">Key Features</h4>
                            <ul className="list-disc list-inside space-y-2 text-gray-600 mt-3">
                                {project.coreElements.map((item, index) => (
                                    <li key={index}>
                                        <AnchorText text={item} onOpen={onOpenAnchor} />
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <h4 className="text-lg font-semibold text-gray-800 mb-3 border-b pb-2">Impact & Outcomes</h4>
                            <ul className="list-disc list-inside space-y-2 text-gray-600 mt-3">
                                {project.outcomes.map((item, index) => (
                                    <li key={index}>
                                        <AnchorText text={item} onOpen={onOpenAnchor} />
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                    
                    {project.skills && project.skills.length > 0 && (
                        <div className="mt-8">
                            <h4 className="text-lg font-semibold text-gray-800 mb-3 border-b pb-2">Skills</h4>
                            <div className="flex flex-wrap gap-2 mt-3">
                                {project.skills.map(skill => (
                                    <span key={skill} className="bg-gray-200 text-gray-700 text-sm font-medium px-3 py-1 rounded-full">{skill}</span>
                                ))}
                            </div>
                        </div>
                    )}

                    {project.url && (
                        <div className="mt-8">
                             <a href={project.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center font-bold text-[#1A1A1A] hover:text-[#FF5E3A] transition-colors duration-300">
                                View Project <LinkIcon className="w-5 h-5 ml-2" />
                            </a>
                        </div>
                    )}
                </div>
            </div>
            <style>{`
                @keyframes fadeInScale {
                    from {
                        opacity: 0;
                        transform: scale(0.95);
                    }
                    to {
                        opacity: 1;
                        transform: scale(1);
                    }
                }
                .animate-fade-in-scale {
                    animation: fadeInScale 0.3s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default ProjectModal;
