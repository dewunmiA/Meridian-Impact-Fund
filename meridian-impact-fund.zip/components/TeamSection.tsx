
import React from 'react';
import { TEAM_DATA } from '../constants';

const LineAccent: React.FC = () => (
    <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/3 w-1/2 max-w-md pointer-events-none" aria-hidden="true">
        <svg width="404" height="404" fill="none" viewBox="0 0 404 404" className="text-[#FF5E3A] opacity-10">
            <path d="M404 0L0 404" stroke="currentColor" strokeWidth="4" />
            <path d="M404 100L100 404" stroke="currentColor" strokeWidth="4" />
            <path d="M404 200L200 404" stroke="currentColor" strokeWidth="4" />
            <path d="M404 300L300 404" stroke="currentColor" strokeWidth="4" />
        </svg>
    </div>
);

const TeamSection: React.FC = () => {
  return (
    <section id="team" className="py-20 bg-[#F8F7F4] relative overflow-hidden scroll-mt-20">
      <LineAccent />
      <div className="container mx-auto px-6 text-center relative z-10">
        <h2 className="text-3xl font-bold text-[#1A1A1A] mb-4">The Meridian Team</h2>
        <p className="text-gray-600 max-w-2xl mx-auto mb-12">
          Our dedicated experts are the driving force behind our mission, bringing a wealth of experience and passion to every project.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {TEAM_DATA.map((member, index) => (
            <div key={index} className="text-center group">
              <div className="relative inline-block mb-4">
                  <div className="absolute inset-0 bg-[#FF5E3A] rounded-full opacity-0 group-hover:opacity-10 transition-opacity duration-300 scale-105"></div>
                  <img 
                    src={member.imageUrl} 
                    alt={member.name} 
                    className="w-40 h-40 rounded-full mx-auto object-cover shadow-lg relative z-10 border-4 border-white"
                  />
              </div>
              <h3 className="text-xl font-bold text-[#1A1A1A]">{member.name}</h3>
              <p className="text-[#FF5E3A] font-semibold mb-2">{member.title}</p>
              <p className="text-gray-600 text-sm">{member.bio}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TeamSection;
