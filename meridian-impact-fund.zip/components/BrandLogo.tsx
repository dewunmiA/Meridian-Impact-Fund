
import React from 'react';

interface BrandLogoProps {
  className?: string;
  iconColor?: string; // Allow overriding icon color if needed, defaults to brand orange
}

const BrandLogo: React.FC<BrandLogoProps> = ({ className = '', iconColor = '#FF5E3A' }) => {
  return (
    <div className={`flex items-center gap-3 md:gap-4 ${className}`}>
       {/* Geometric Icon */}
       <svg className="w-10 h-10 md:w-12 md:h-12 flex-shrink-0" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* A stylized representation of the diamond fan pattern using the brand orange */}
          <g fill={iconColor} opacity="0.9">
            {/* Center column */}
            <rect x="46" y="10" width="8" height="8" transform="rotate(45 50 14)" />
            <rect x="46" y="25" width="8" height="8" transform="rotate(45 50 29)" />
            <rect x="46" y="40" width="8" height="8" transform="rotate(45 50 44)" />
            <rect x="46" y="55" width="8" height="8" transform="rotate(45 50 59)" />
            <rect x="48" y="70" width="4" height="15" rx="2" /> {/* Stem */}

            {/* Left columns - radiating */}
            <rect x="32" y="22" width="7" height="7" transform="rotate(30 35.5 25.5)" />
            <rect x="28" y="38" width="7" height="7" transform="rotate(25 31.5 41.5)" />
            <rect x="26" y="54" width="7" height="7" transform="rotate(20 29.5 57.5)" />

            <rect x="18" y="35" width="6" height="6" transform="rotate(15 21 38)" />
            <rect x="14" y="50" width="6" height="6" transform="rotate(10 17 53)" />

            {/* Right columns - radiating */}
            <rect x="61" y="22" width="7" height="7" transform="rotate(60 64.5 25.5)" />
            <rect x="65" y="38" width="7" height="7" transform="rotate(65 68.5 41.5)" />
            <rect x="67" y="54" width="7" height="7" transform="rotate(70 70.5 57.5)" />

            <rect x="76" y="35" width="6" height="6" transform="rotate(75 79 38)" />
            <rect x="80" y="50" width="6" height="6" transform="rotate(80 83 53)" />
          </g>
       </svg>
       
       {/* Vertical Separator */}
       <div className="h-10 md:h-12 w-px bg-current opacity-40"></div>
       
       {/* Stacked Text - uses current text color (black/white) */}
       <div className="flex flex-col justify-between h-9 md:h-10 leading-none select-none text-current">
          <span className="text-[10px] md:text-xs font-light tracking-[0.15em] uppercase font-sans">Meridian</span>
          <span className="text-[10px] md:text-xs font-light tracking-[0.15em] uppercase font-sans">Impact</span>
          <span className="text-[10px] md:text-xs font-light tracking-[0.15em] uppercase font-sans">Fund</span>
       </div>
    </div>
  );
};

export default BrandLogo;
