
import React, { useState } from 'react';
import { PROJECTS_DATA } from '../constants';
import { Project } from '../types';
import ProjectModal from './ProjectModal';
import AnchorText from './AnchorText';

const ArrowRightIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3" />
    </svg>
);


interface AccordionItemProps {
    project: Project;
    onViewDetails: () => void;
    onOpenAnchor: () => void;
}

const AccordionItem: React.FC<AccordionItemProps> = ({ project, onViewDetails, onOpenAnchor }) => {
    const bgClass = project.featured ? 'bg-[#FF5E3A]/5' : 'bg-white';
    const hoverBgClass = project.featured ? 'hover:bg-[#FF5E3A]/10' : 'hover:bg-gray-50';

    return (
        <div className={`border-b border-gray-200 last:border-b-0 ${bgClass}`}>
            <div className={`w-full flex justify-between items-center text-left py-6 px-4 transition-colors duration-300 ${hoverBgClass}`}>
                <div className="flex-grow pr-4">
                    <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="text-xl font-bold text-[#1A1A1A]">{project.title}</h3>
                        {project.featured && (
                            <span className="bg-[#FF5E3A] text-white text-xs font-bold px-2.5 py-1 rounded-full tracking-wider">
                                FEATURED
                            </span>
                        )}
                    </div>
                    <p className="text-sm text-gray-500 font-semibold mt-1 mb-2">{project.association}</p>
                    {/* Preview of description with Anchor Text */}
                    <div className="text-sm text-gray-600 line-clamp-2 md:line-clamp-none md:block hidden">
                        <AnchorText text={project.description.substring(0, 150) + (project.description.length > 150 ? "..." : "")} onOpen={onOpenAnchor} />
                    </div>
                </div>
                <button
                    onClick={onViewDetails}
                    className="group flex-shrink-0 flex items-center text-sm font-bold text-[#1A1A1A] hover:text-[#FF5E3A] transition-colors duration-300 p-2"
                    aria-label={`View details for ${project.title}`}
                >
                    <span className="hidden sm:inline">View Details</span>
                    <ArrowRightIcon className="w-5 h-5 sm:ml-2 transition-transform duration-300 group-hover:translate-x-1" />
                </button>
            </div>
        </div>
    );
};


interface ProjectsSectionProps {
    onOpenAnchor: () => void;
}

const ProjectsSection: React.FC<ProjectsSectionProps> = ({ onOpenAnchor }) => {
    const [selectedProject, setSelectedProject] = useState<Project | null>(null);

    const handleViewDetails = (project: Project) => {
        setSelectedProject(project);
    };
    
    const handleCloseModal = () => {
        setSelectedProject(null);
    }

    return (
        <section id="projects" className="py-20 bg-[#FFFBF5] scroll-mt-20">
            <div className="container mx-auto px-6">
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-[#1A1A1A] mb-2">Our Work</h2>
                    <div className="inline-block w-24 h-1 bg-[#FF5E3A] rounded-full mb-4"></div>
                    <p className="text-gray-600 max-w-2xl mx-auto mb-12">
                        We partner with organizations to design and implement strategies that drive measurable social impact. Here are some of our past projects.
                    </p>
                </div>
                <div className="max-w-4xl mx-auto border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                    {PROJECTS_DATA.map((project, index) => (
                        <AccordionItem 
                            key={index} 
                            project={project}
                            onViewDetails={() => handleViewDetails(project)}
                            onOpenAnchor={onOpenAnchor}
                        />
                    ))}
                </div>
            </div>
            <ProjectModal project={selectedProject} onClose={handleCloseModal} onOpenAnchor={onOpenAnchor} />
        </section>
    );
};

export default ProjectsSection;
