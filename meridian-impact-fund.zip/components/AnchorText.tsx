
import React from 'react';

interface Props {
  text: string;
  onOpen: () => void;
  className?: string;
}

const AnchorText: React.FC<Props> = ({ text, onOpen, className }) => {
  if (!text.includes('ANCHOR Framework')) {
    return <span className={className}>{text}</span>;
  }
  
  const parts = text.split(/(ANCHOR Framework)/g);
  
  return (
    <span className={className}>
      {parts.map((part, i) => 
        part === 'ANCHOR Framework' ? (
          <button 
            key={i} 
            onClick={(e) => { 
                e.stopPropagation(); 
                onOpen(); 
            }} 
            className="text-[#FF5E3A] font-bold hover:underline cursor-pointer inline-block focus:outline-none transition-colors"
            title="Click to view framework details"
          >
            {part}
          </button>
        ) : part
      )}
    </span>
  );
};

export default AnchorText;
