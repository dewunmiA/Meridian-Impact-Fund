
import React from 'react';

const LOGOS = [
  { label: 'UNDP', fullName: 'United Nations Development Programme' },
  { label: 'Bill & Melinda Gates Foundation', fullName: 'Bill & Melinda Gates Foundation' },
  { label: 'Tony Elumelu Foundation', fullName: 'Tony Elumelu Foundation' },
  { label: 'Albright Stonebridge Group', fullName: 'Albright Stonebridge Group' },
  { label: 'Lagos Business School', fullName: 'Lagos Business School' },
  { label: 'European Union', fullName: 'European Union' },
  { label: 'GIZ', fullName: 'GIZ' },
  { label: 'AFD', fullName: 'Agence Française de Développement' },
  { label: 'ICRC', fullName: 'International Committee of the Red Cross' },
];

const LogoShowcase: React.FC = () => {
  return (
    <section className="py-12 border-b border-gray-200/60">
      <div className="container mx-auto px-6">
        <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-8 grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
          {LOGOS.map((logo, index) => (
            <div 
                key={index} 
                className="group flex justify-center items-center px-2 cursor-default"
                title={logo.fullName}
            >
               {/* 
                  Using styled text as placeholders for logos. 
                  In a production environment, these would be <img> tags pointing to SVGs.
               */}
               <h3 className="text-lg md:text-xl font-bold text-gray-800 font-sans tracking-tight">
                 {logo.label}
               </h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LogoShowcase;
