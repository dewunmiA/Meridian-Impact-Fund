
import React from 'react';

const ImpactSection: React.FC = () => {
  return (
    <section id="impact" className="py-20 bg-[#1A1A1A] text-white scroll-mt-20">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl font-bold mb-12">Our Global Impact</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="p-4 bg-[#252525] rounded-xl border border-gray-800">
            <h3 className="text-5xl font-bold text-[#FF5E3A]">15+</h3>
            <p className="mt-2 text-lg text-gray-300">Countries Reached</p>
          </div>
          <div className="p-4 bg-[#252525] rounded-xl border border-gray-800">
            <h3 className="text-5xl font-bold text-[#FF5E3A]">$5M+</h3>
            <p className="mt-2 text-lg text-gray-300">In Resources Mobilised</p>
          </div>
          <div className="p-4 bg-[#252525] rounded-xl border border-gray-800">
            <h3 className="text-5xl font-bold text-[#FF5E3A]">120+</h3>
            <p className="mt-2 text-lg text-gray-300">Partnerships Forged</p>
          </div>
          <div className="p-4 bg-[#252525] rounded-xl border border-gray-800">
            <h3 className="text-5xl font-bold text-[#FF5E3A]">50,000+</h3>
            <p className="mt-2 text-lg text-gray-300">Lives Empowered</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ImpactSection;
