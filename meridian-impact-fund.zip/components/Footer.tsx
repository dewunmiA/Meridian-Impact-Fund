
import React, { useState } from 'react';
import { NAV_LINKS } from '../constants';
import BrandLogo from './BrandLogo';

interface FooterProps {
    onNavigate: (view: 'home' | 'founder', targetId?: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    
    // Ensure 'team' links navigate to the founder view and scroll to the team section
    if (targetId === 'team') {
        onNavigate('founder', 'team');
    } else if (targetId === 'founder') {
        onNavigate('founder');
    } else {
        onNavigate('home', targetId);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormState({
        ...formState,
        [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
    // In a real app, you would send data to a backend here
  };

  const resetForm = () => {
    setIsSubmitted(false);
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <footer className="bg-[#1A1A1A] text-white">
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand Column */}
          <div>
            <div className="mb-6 text-white">
                <BrandLogo />
            </div>
            <p className="text-gray-400 leading-relaxed max-w-sm">
              Championing equitable development and empowering communities through strategic collaboration, resource mobilisation, and capacity building across Africa.
            </p>
          </div>

          {/* Navigation Column */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-[#FF5E3A] uppercase tracking-wider">Quick Links</h3>
            <ul className="space-y-3">
              {NAV_LINKS.map(link => (
                <li key={link.href}>
                  <a 
                    href={link.href} 
                    onClick={(e) => handleNavClick(e, link.href)}
                    className="text-gray-400 hover:text-white transition-colors duration-300 flex items-center"
                  >
                    <span className="mr-2 text-[#FF5E3A]">›</span> {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect/Form Column */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-[#FF5E3A] uppercase tracking-wider">Connect With Us</h3>
            
            {isSubmitted ? (
                <div className="bg-[#FF5E3A]/10 border border-[#FF5E3A] p-6 rounded-lg animate-fade-in-scale">
                    <svg className="w-12 h-12 text-[#FF5E3A] mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <h4 className="text-xl font-bold mb-2">Message Sent!</h4>
                    <p className="text-gray-300 text-sm mb-4">Thank you for reaching out. We will get back to you shortly.</p>
                    <button 
                        onClick={resetForm}
                        className="text-[#FF5E3A] hover:text-white text-sm font-semibold transition-colors"
                    >
                        Send another message
                    </button>
                </div>
            ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                    <p className="text-gray-400 text-sm mb-2">Have questions or want to partner? Drop us a message below.</p>
                    <div>
                        <input 
                            type="text" 
                            name="name"
                            placeholder="Name" 
                            value={formState.name}
                            onChange={handleInputChange}
                            required
                            className="w-full bg-[#252525] border border-gray-700 rounded px-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-[#FF5E3A] focus:ring-1 focus:ring-[#FF5E3A] transition-all text-sm"
                        />
                    </div>
                    <div>
                        <input 
                            type="email" 
                            name="email"
                            placeholder="Email Address" 
                            value={formState.email}
                            onChange={handleInputChange}
                            required
                            className="w-full bg-[#252525] border border-gray-700 rounded px-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-[#FF5E3A] focus:ring-1 focus:ring-[#FF5E3A] transition-all text-sm"
                        />
                    </div>
                    <div>
                        <textarea 
                            name="message"
                            placeholder="Your Message" 
                            rows={3}
                            value={formState.message}
                            onChange={handleInputChange}
                            required
                            className="w-full bg-[#252525] border border-gray-700 rounded px-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-[#FF5E3A] focus:ring-1 focus:ring-[#FF5E3A] transition-all text-sm resize-none"
                        />
                    </div>
                    <button 
                        type="submit" 
                        className="w-full bg-[#FF5E3A] text-white font-bold py-2.5 px-6 rounded hover:bg-[#E04D2B] transition-colors duration-300 text-sm shadow-md"
                    >
                        Send Message
                    </button>
                </form>
            )}
          </div>
        </div>
        <div className="mt-16 border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Meridian Impact Fund. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
