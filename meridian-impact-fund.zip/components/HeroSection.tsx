
import React from 'react';

const HeroSection: React.FC = () => {
  const handleScrollToContact = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      id="home" 
      className="relative min-h-screen pt-32 pb-20 overflow-hidden flex items-center"
    >
      {/* Background Gradient Blob */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-b from-[#FF5E3A]/10 to-transparent rounded-full blur-3xl opacity-50 translate-x-1/3 -translate-y-1/4 pointer-events-none"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
            
            {/* Left Content */}
            <div className="max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF5E3A]/10 text-[#FF5E3A] text-xs font-bold uppercase tracking-wider mb-6">
                    <span className="w-2 h-2 rounded-full bg-[#FF5E3A]"></span>
                    Social Impact & Ecosystem Design
                </div>
                
                <h1 className="text-4xl md:text-6xl font-bold mb-6 text-[#1A1A1A] tracking-tight leading-[1.1]">
                    Creating Value | <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF5E3A] to-orange-400">
                        Sustaining Impact.
                    </span>
                </h1>
                <p className="text-xl text-gray-600 mb-10 leading-relaxed max-w-lg">
                    We are a design studio that helps individuals, organisations, and coalitions design, fund, and deliver programmes that transform systems, not just run projects.
                </p>
                <div className="flex flex-wrap gap-4">
                    <a 
                        href="#contact" 
                        onClick={handleScrollToContact}
                        className="bg-black text-white font-semibold py-4 px-8 rounded-full hover:bg-[#333] transition-all duration-300 shadow-xl hover:shadow-2xl hover:-translate-y-1"
                    >
                        Partner With Us
                    </a>
                    <a 
                        href="#about"
                        className="bg-transparent border border-gray-300 text-[#1A1A1A] font-semibold py-4 px-8 rounded-full hover:border-black transition-all duration-300"
                    >
                        Read Our Vision
                    </a>
                </div>
            </div>

            {/* Right Visuals - Floating Cards Composition */}
            <div className="relative h-[500px] w-full hidden lg:block">
                
                {/* Dotted Line Connection SVG */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-0" xmlns="http://www.w3.org/2000/svg">
                    <path d="M 120 100 Q 250 50 400 150 T 550 350" fill="none" stroke="#FF5E3A" strokeWidth="2" strokeDasharray="6 6" strokeOpacity="0.2" />
                    <path d="M 400 150 Q 300 300 150 380" fill="none" stroke="#FF5E3A" strokeWidth="2" strokeDasharray="6 6" strokeOpacity="0.2" />
                </svg>

                {/* Keyword Pill 1 */}
                <div className="absolute top-20 left-10 glass-card px-5 py-3 rounded-full shadow-lg w-auto animate-float-slow z-10 bg-white/80 border-0 flex items-center gap-3">
                     <div className="w-3 h-3 rounded-full bg-[#FF5E3A]"></div>
                     <span className="text-sm font-bold text-gray-800">Sustainable Growth</span>
                </div>

                {/* Keyword Pill 2 */}
                <div className="absolute top-10 right-20 glass-card px-5 py-3 rounded-full shadow-lg w-auto animate-float-medium z-20 bg-white/80 border-0 flex items-center gap-3">
                     <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                     <span className="text-sm font-bold text-gray-800">Ecosystem Design</span>
                </div>

                {/* Keyword Pill 3 */}
                <div className="absolute bottom-32 left-1/4 glass-card px-5 py-3 rounded-full shadow-lg w-auto animate-float-fast z-10 bg-white/80 border-0 flex items-center gap-3">
                     <div className="w-3 h-3 rounded-full bg-green-500"></div>
                     <span className="text-sm font-bold text-gray-800">Strategic Philanthropy</span>
                </div>

                {/* Keyword Pill 4 */}
                <div className="absolute bottom-40 right-10 glass-card px-5 py-3 rounded-full shadow-lg w-auto animate-bounce-slow z-20 bg-white/80 border-0 flex items-center gap-3">
                     <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                     <span className="text-sm font-bold text-gray-800">Capital Mobilisation</span>
                </div>

                 {/* Central Visual Element to anchor the keywords */}
                 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-gradient-to-tr from-[#FF5E3A]/20 to-orange-100/50 rounded-full blur-xl z-0"></div>

            </div>
        </div>
      </div>
      <style>{`
        @keyframes float-slow {
            0%, 100% { transform: translate(0, 0); }
            50% { transform: translate(0, -10px); }
        }
        @keyframes float-medium {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }
        @keyframes float-fast {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-6px); }
        }
        @keyframes bounce-slow {
             0%, 100% { transform: translateY(0); }
             50% { transform: translateY(-4px); }
        }
        .animate-float-slow { animation: float-slow 5s ease-in-out infinite; }
        .animate-float-medium { animation: float-medium 4s ease-in-out infinite; }
        .animate-float-fast { animation: float-fast 3.5s ease-in-out infinite; }
        .animate-bounce-slow { animation: bounce-slow 4.5s ease-in-out infinite; }
      `}</style>
    </section>
  );
};

export default HeroSection;
