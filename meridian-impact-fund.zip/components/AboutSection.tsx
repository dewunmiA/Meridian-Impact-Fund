
import React from 'react';

const DottedPattern: React.FC = () => (
    <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 pointer-events-none" aria-hidden="true">
        <svg width="200" height="200" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-[#FF5E3A] opacity-20">
            <defs>
                <pattern id="about-dot-pattern" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                    <circle cx="4" cy="4" r="2" fill="currentColor"/>
                </pattern>
            </defs>
            <rect width="200" height="200" fill="url(#about-dot-pattern)"/>
        </svg>
    </div>
);

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-[#FFFBF5] overflow-hidden scroll-mt-20">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="wow fadeIn">
            <img 
                src="https://i.pinimg.com/1200x/27/a1/a3/27a1a38382d67e50e0a6579026df2218.jpg" 
                alt="Meridian Impact Fund Team Strategizing" 
                className="rounded-lg shadow-xl w-full h-auto object-cover"
            />
          </div>
          <div className="relative">
            <DottedPattern />
            <div className="relative z-10">
                <h2 className="text-3xl font-bold text-[#1A1A1A] mb-6">Our Vision for Africa</h2>
                <p className="text-gray-600 mb-8 leading-relaxed text-lg">
                  We envision an Africa where impact is engineered for sustainability. A future where development is driven by designed systems rather than temporary interventions, ensuring that every resource mobilised translates into lasting economic and social resilience for communities.
                </p>
                <div className="border-l-4 border-[#FF5E3A] pl-6 py-2">
                    <h3 className="text-xl font-bold text-[#1A1A1A] mb-3">Our Mission</h3>
                    <p className="text-gray-600 italic text-lg leading-relaxed">
                    To be the architects of systemic change. We guide individuals, organizations, and coalitions to design, fund, and deliver impact that connects directly to the bottom line. By moving beyond isolated projects to build robust ecosystems, we ensure that doing good is not just a moral imperative, but a sustainable value proposition.
                    </p>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
