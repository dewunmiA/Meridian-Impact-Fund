
import React from 'react';
import BrandLogo from './BrandLogo';

const LogoPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#F8F7F4] flex flex-col items-center justify-center pt-32 pb-20">
        <div className="bg-white p-24 rounded-[3rem] shadow-2xl border border-gray-100 flex items-center justify-center">
            <div className="transform scale-[2.5] md:scale-[3.5] origin-center p-4">
                <BrandLogo />
            </div>
        </div>
        <div className="mt-12 text-center">
            <h1 className="text-2xl font-bold text-[#1A1A1A] mb-2">Brand Identity</h1>
            <p className="text-gray-500 font-mono text-sm">Meridian Impact Fund</p>
            <div className="flex gap-4 mt-6 justify-center">
                <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-[#FF5E3A] rounded-full shadow-sm"></div>
                    <span className="text-xs text-gray-600 font-mono">#FF5E3A</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-[#1A1A1A] rounded-full shadow-sm"></div>
                    <span className="text-xs text-gray-600 font-mono">#1A1A1A</span>
                </div>
                 <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-[#F8F7F4] border border-gray-300 rounded-full shadow-sm"></div>
                    <span className="text-xs text-gray-600 font-mono">#F8F7F4</span>
                </div>
            </div>
        </div>
    </div>
  );
};

export default LogoPage;
