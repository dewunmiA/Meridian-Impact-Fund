
import React from 'react';
import TeamSection from './TeamSection';
import AnchorText from './AnchorText';

interface FounderPageProps {
    onOpenAnchor: () => void;
    onNavigate?: (view: 'home' | 'founder', targetId?: string) => void;
}

const FounderPage: React.FC<FounderPageProps> = ({ onOpenAnchor, onNavigate }) => {

  return (
    <div className="bg-[#F8F7F4]">
      {/* Hero / Intro */}
      <section className="relative pt-32 pb-20 bg-[#1A1A1A] text-white overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10 transform translate-x-1/3 -translate-y-1/4">
             <svg width="600" height="600" viewBox="0 0 600 600" fill="currentColor">
                <circle cx="300" cy="300" r="300" />
             </svg>
        </div>
        <div className="container mx-auto px-6 relative z-10">
            <div className="flex flex-col md:flex-row gap-12 items-center">
                <div className="w-full md:w-1/3">
                    <a href="https://www.dewunmiaisha.com" target="_blank" rel="noopener noreferrer" className="block group">
                        <img 
                            src="https://i.pinimg.com/736x/c0/38/54/c0385464e76b28e042155b400932c7d3.jpg" 
                            alt="Dewunmi Aisha" 
                            className="rounded-xl shadow-2xl border-4 border-[#FF5E3A] w-full max-w-sm mx-auto group-hover:scale-[1.02] transition-transform duration-300 object-cover"
                        />
                    </a>
                </div>
                <div className="w-full md:w-2/3">
                    <div className="inline-block bg-[#FF5E3A] text-white text-xs font-bold px-3 py-1 rounded-full tracking-wider mb-4">
                        THE FOUNDER
                    </div>
                    <a href="https://www.dewunmiaisha.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#FF5E3A] transition-colors inline-block">
                        <h1 className="text-4xl md:text-5xl font-bold mb-4 font-serif">Dewunmi Aisha</h1>
                    </a>
                    <p className="text-xl md:text-2xl text-gray-200 font-light mb-6">
                        Social Impact & Partnerships Strategist
                    </p>
                    <div className="h-1 w-24 bg-[#FF5E3A] rounded-full mb-8"></div>
                    <blockquote className="text-lg md:text-xl italic text-gray-300 border-l-4 border-white/20 pl-6 py-2">
                        "Impact at scale is an act of design. It requires an architect who can build systems of trust, align incentives, and mobilise ecosystems to bridge the gap between profit and purpose."
                    </blockquote>
                </div>
            </div>
        </div>
      </section>

      {/* Bio & Stats */}
      <section className="py-20">
          <div className="container mx-auto px-6">
              <div className="grid md:grid-cols-2 gap-16">
                  <div>
                      <h2 className="text-3xl font-bold text-[#1A1A1A] mb-6">About Dewunmi</h2>
                      <div className="prose text-gray-600 leading-relaxed space-y-4">
                          <p>
                              Dewunmi Aisha is a philanthropic and social impact strategist with over 15 years of experience, specializing in designing partnership and funding frameworks for major institutions to drive development across Africa.
                          </p>
                          <p>
                              She works at the intersection of philanthropy, policy, and private sector innovation, advising foundations, multilateral agencies, and universities on how to align intent, funding, and execution for measurable systems change.
                          </p>
                          <p>
                              Her career has been defined by a commitment to engineering collaboration. She believes that traditional, siloed approaches to social impact are no longer sufficient, and that the future belongs to those who can build robust frameworks for multi-stakeholder action.
                          </p>
                          <p className="pt-4">
                              <a 
                                href="https://www.dewunmiaisha.com" 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="inline-flex items-center text-[#FF5E3A] font-bold hover:underline gap-2 transition-all"
                              >
                                  Visit Personal Website 
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                              </a>
                          </p>
                      </div>
                      
                      <div className="mt-8">
                          <h3 className="text-lg font-bold text-[#1A1A1A] mb-4">Key Credentials</h3>
                          <ul className="space-y-3">
                              <li className="flex gap-3">
                                  <span className="text-[#FF5E3A] text-xl">💼</span>
                                  <span className="text-gray-700"><strong>Experience:</strong> Eden Venture Group, UNDP, Tony Elumelu Foundation, The Commonwealth Mission to the UN, PwC.</span>
                              </li>
                              <li className="flex gap-3">
                                  <span className="text-[#FF5E3A] text-xl">🎓</span>
                                  <span className="text-gray-700"><strong>Education:</strong> Master’s in Development Economics and African Studies; Bachelor’s in Economics and African Studies.</span>
                              </li>
                              <li className="flex gap-3">
                                  <span className="text-[#FF5E3A] text-xl">⚓</span>
                                  <span className="text-gray-700"><strong>Creator:</strong> The <AnchorText text="ANCHOR Framework" onOpen={onOpenAnchor} className="" /> for Collaboration.</span>
                              </li>
                              <li className="flex gap-3">
                                  <span className="text-[#FF5E3A] text-xl">🏆</span>
                                  <span className="text-gray-700"><strong>Recognition:</strong> Named one of the Top 50 Leading Ladies in Corporate Nigeria (Leading Ladies Africa, 2020).</span>
                              </li>
                          </ul>
                      </div>
                  </div>
                  
                  <div className="flex flex-col gap-6">
                      <div className="bg-[#FF5E3A]/5 p-8 rounded-xl border border-[#FF5E3A]/10">
                          <h3 className="text-xl font-bold text-[#1A1A1A] mb-6">Career Impact Highlights</h3>
                          <div className="space-y-8">
                                <div>
                                    <div className="text-5xl font-bold text-[#FF5E3A] mb-1">$100 Million+</div>
                                    <div className="text-lg font-bold text-gray-800">Managed in Donor Partnerships</div>
                                    <p className="text-sm text-gray-600 mt-1">While at the Tony Elumelu Foundation, scaling entrepreneurship support across 54 African countries.</p>
                                </div>
                                <div>
                                    <div className="text-5xl font-bold text-[#FF5E3A] mb-1">54</div>
                                    <div className="text-lg font-bold text-gray-800">African Countries Reached</div>
                                    <p className="text-sm text-gray-600 mt-1">Led high-profile pan-African initiatives for the Bill & Melinda Gates Foundation, UNDP, and Albright Stonebridge Group.</p>
                                </div>
                          </div>
                      </div>
                      <div className="bg-[#FF5E3A] text-white p-8 rounded-xl shadow-lg">
                          <h3 className="text-2xl font-bold mb-4">The Impact OS</h3>
                          <p className="mb-4">
                              Dewunmi has developed a comprehensive methodology—an "Impact Operating System"—for designing, funding, and executing high-stakes, multi-stakeholder initiatives.
                          </p>
                          <ul className="list-disc list-inside space-y-2 text-white/90 font-medium">
                              <li>Design Before Deployment</li>
                              <li>Collaboration as Infrastructure</li>
                              <li>Narrative as a Catalyst</li>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
      </section>

      {/* Team Section */}
      <TeamSection />
    </div>
  );
};

export default FounderPage;
