
import React, { useState } from 'react';
import { SERVICES_DATA } from '../constants';
import AnchorText from './AnchorText';

interface ServicesSectionProps {
    onOpenAnchor: () => void;
}

const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenAnchor }) => {
  const [activeTab, setActiveTab] = useState(0);

  // Helper to determine gradient based on active tab
  const getGradientClass = (index: number) => {
    switch(index) {
        case 0: return 'from-amber-50 to-amber-100'; // Legacy
        case 1: return 'from-orange-50 to-orange-100'; // Strategy
        case 2: return 'from-blue-50 to-blue-100'; // Partnerships
        case 3: return 'from-purple-50 to-purple-100'; // Implementation
        case 4: return 'from-green-50 to-green-100'; // Storytelling
        default: return 'from-gray-50 to-gray-100';
    }
  };

  // Helper to get badge text based on active tab
  const getBadgeText = (index: number) => {
      switch(index) {
          case 0: return "Legacy & Wealth";
          case 1: return "Strategic Design";
          case 2: return "Resource Mobilisation";
          case 3: return "Systemic Change";
          case 4: return "Impact Storytelling";
          default: return "Focus Area";
      }
  };

  // Curated images for each service tab
  const getServiceImage = (index: number) => {
      const images = [
          "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&q=80&w=600", // Wealth/Legacy
          "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=600", // Strategy/Boardroom
          "https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&q=80&w=600", // Partnerships/Handshake
          "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=600", // Implementation/Growth
          "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&q=80&w=600"  // Storytelling/Media
      ];
      return images[index] || images[0];
  };

  return (
    <section id="services" className="py-24 bg-[#F8F7F4] relative overflow-hidden scroll-mt-20">
      <div className="container mx-auto px-6 relative z-10">
        <div className="mb-12">
            <h2 className="text-4xl font-bold text-[#1A1A1A] mb-6">Choose Your Path to Impact</h2>
            <p className="text-gray-700 max-w-4xl text-xl font-medium leading-relaxed mb-4">
                <AnchorText 
                    text="We serve Individuals, Family Offices, NGOs, Corporates, Foundations/ Philanthropies, and Governments. Leveraging our proprietary ANCHOR Framework, we help you design strategies that connect your impact goals directly to your bottom line, ensuring sustainability while driving systemic change."
                    onOpen={onOpenAnchor}
                />
            </p>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-3 mb-10">
            {SERVICES_DATA.map((service, index) => (
                <button
                    key={index}
                    onClick={() => setActiveTab(index)}
                    className={`px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300 border ${
                        activeTab === index 
                        ? 'bg-black text-white border-black shadow-lg' 
                        : 'bg-transparent text-gray-600 border-gray-300 hover:border-gray-800'
                    }`}
                >
                    {service.title}
                </button>
            ))}
        </div>

        {/* Content Card */}
        <div className="bg-gradient-to-br from-[#E8F5E9] to-[#F1F8E9] rounded-[3rem] p-8 md:p-12 lg:p-16 shadow-sm border border-gray-100 relative overflow-hidden">
             {/* Gradient Overlay specific to tab to vary colors slightly */}
             <div className={`absolute inset-0 opacity-50 pointer-events-none bg-gradient-to-br ${getGradientClass(activeTab)}`}></div>

             <div className="relative z-10 grid md:grid-cols-2 gap-12 items-center">
                 <div>
                     <h3 className="text-3xl md:text-4xl font-bold text-[#1A1A1A] mb-6 leading-tight">
                         {SERVICES_DATA[activeTab].title}
                     </h3>
                     <div className="space-y-4">
                        {SERVICES_DATA[activeTab].items.map((item, idx) => (
                            <div key={idx} className="flex items-start bg-white/60 backdrop-blur-sm p-4 rounded-xl border border-white/50">
                                <div className="mt-1 w-5 h-5 rounded-full bg-[#FF5E3A] flex items-center justify-center flex-shrink-0 text-white text-xs mr-3">
                                    ✓
                                </div>
                                <p className="text-gray-800 font-medium text-lg">
                                    <AnchorText text={item} onOpen={onOpenAnchor} />
                                </p>
                            </div>
                        ))}
                     </div>
                 </div>
                 <div className="relative h-full min-h-[300px] flex items-center justify-center">
                     {/* Decorative image/graphic area */}
                      <div className="relative w-full aspect-square max-w-md">
                          <div className="absolute inset-0 bg-black/5 rounded-full transform rotate-6 scale-95"></div>
                          <img 
                            src={getServiceImage(activeTab)} 
                            alt="Service Visualization" 
                            className="relative w-full h-full object-cover rounded-[2rem] shadow-2xl transform transition-all duration-500 hover:scale-[1.02]"
                          />
                          
                          {/* Floating Badge */}
                          <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-2xl shadow-xl max-w-[180px]">
                              <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Focus Area</p>
                              <p className="text-sm font-bold text-[#1A1A1A]">
                                  {getBadgeText(activeTab)}
                              </p>
                          </div>
                      </div>
                 </div>
             </div>
        </div>

      </div>
    </section>
  );
};

export default ServicesSection;
