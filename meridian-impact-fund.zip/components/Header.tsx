
import React, { useState, useEffect } from 'react';
import { NAV_LINKS } from '../constants';
import BrandLogo from './BrandLogo';

interface HeaderProps {
    onNavigate: (view: 'home' | 'founder', targetId?: string) => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    
    // Map 'team' navigation to the 'founder' view which contains the Team page
    if (targetId === 'team') {
        onNavigate('founder', 'team');
    } else if (targetId === 'founder') {
        onNavigate('founder');
    } else {
        onNavigate('home', targetId);
    }
    
    setIsMenuOpen(false);
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-[#F8F7F4]/90 backdrop-blur-md py-3 shadow-sm' : 'bg-transparent py-5'}`}>
      <div className="container mx-auto px-6 grid grid-cols-2 md:grid-cols-12 items-center gap-4">
        
        {/* Logo Section */}
        <div className="md:col-span-3 flex justify-start">
            <a 
            href="#home" 
            onClick={(e) => handleNavClick(e, '#home')}
            className="text-[#1A1A1A]"
            aria-label="Meridian Impact Fund Home"
            >
            <BrandLogo />
            </a>
        </div>

        {/* Desktop Navigation - Centered */}
        <nav className="hidden md:flex md:col-span-6 justify-center space-x-6 lg:space-x-8">
          {NAV_LINKS.filter(l => l.href !== '#contact').map(link => (
            <a 
              key={link.href} 
              href={link.href} 
              onClick={(e) => handleNavClick(e, link.href)}
              className="text-sm font-medium text-gray-600 hover:text-black transition-colors duration-200 whitespace-nowrap"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="hidden md:flex md:col-span-3 justify-end items-center space-x-3">
            <a 
                href="#contact" 
                onClick={(e) => handleNavClick(e, '#contact')}
                className="text-sm font-semibold px-5 py-2.5 rounded-full bg-black text-white hover:bg-[#FF5E3A] transition-colors shadow-lg"
            >
                Contact Us
            </a>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex justify-end">
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="focus:outline-none text-[#1A1A1A]">
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-[#F8F7F4] py-4 shadow-lg absolute w-full left-0 border-t border-gray-100">
          <nav className="flex flex-col items-center space-y-4 px-6">
            {NAV_LINKS.map(link => (
              <a 
                key={link.href} 
                href={link.href} 
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-gray-700 hover:text-black font-semibold w-full text-center py-2"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
