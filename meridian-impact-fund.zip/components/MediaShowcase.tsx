
import React from 'react';

const MEDIA_OUTLETS = [
  { name: 'BENZINGA', url: '#', className: 'text-blue-900 font-sans tracking-tight' },
  { name: 'NBC', url: '#', className: 'text-purple-700 font-bold tracking-tighter' },
  { name: 'abc', url: '#', className: 'text-black font-serif font-black lowercase text-3xl' },
  { name: 'OCBS', url: '#', className: 'text-blue-900 font-bold tracking-widest' },
  { name: 'FOX NEWS', url: '#', className: 'text-blue-800 font-black font-sans' },
  { name: 'USA TODAY', url: '#', className: 'text-blue-500 font-bold font-serif' },
  { name: 'DIGITAL JOURNAL', url: '#', className: 'text-red-700 font-serif leading-none' },
];

const MediaShowcase: React.FC = () => {
  // Duplicate the array to ensure seamless scrolling
  const scrollingItems = [...MEDIA_OUTLETS, ...MEDIA_OUTLETS, ...MEDIA_OUTLETS, ...MEDIA_OUTLETS];

  return (
    <section className="py-16 bg-[#FFFBF5] overflow-hidden relative">
        {/* Faded edges effect matching cream bg */}
        <div className="absolute top-0 left-0 w-20 md:w-40 h-full bg-gradient-to-r from-[#FFFBF5] to-transparent z-10 pointer-events-none"></div>
        <div className="absolute top-0 right-0 w-20 md:w-40 h-full bg-gradient-to-l from-[#FFFBF5] to-transparent z-10 pointer-events-none"></div>

      <div className="container mx-auto px-6 mb-10 text-center relative z-20">
        <h3 className="text-3xl font-black text-[#1A1A1A] uppercase tracking-widest mb-2">
          As Seen On
        </h3>
        <div className="w-16 h-1 bg-gray-200 mx-auto rounded-full"></div>
      </div>
      
      <div className="relative w-full flex overflow-hidden">
        <div className="flex animate-marquee hover:pause py-4">
          {scrollingItems.map((media, index) => (
            <div key={index} className="flex-shrink-0 mx-4 md:mx-6">
               <a 
                 href={media.url} 
                 target="_blank" 
                 rel="noopener noreferrer" 
                 className="block group"
                 aria-label={`Read about us on ${media.name}`}
               >
                  <div className="w-28 h-28 md:w-36 md:h-36 bg-white rounded-full shadow-[0_4px_14px_0_rgba(0,0,0,0.1)] hover:shadow-[0_6px_20px_0_rgba(0,0,0,0.15)] flex items-center justify-center p-4 transform transition-all duration-300 group-hover:-translate-y-1 border border-gray-50">
                      <span className={`text-center text-sm md:text-base ${media.className}`}>
                        {media.name}
                      </span>
                  </div>
               </a>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        .animate-marquee {
          animation: marquee 40s linear infinite;
        }
        .hover\\:pause:hover {
          animation-play-state: paused;
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </section>
  );
};

export default MediaShowcase;
